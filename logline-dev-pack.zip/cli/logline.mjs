#!/usr/bin/env node
import fs from 'fs';
import path from 'path';
import url from 'url';

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));
const cfgPath = path.join(__dirname, '.logline-cli.json');

function loadCfg(){
  if(fs.existsSync(cfgPath)) return JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
  return { baseUrl: 'https://api.logline.world', apiKey: 'dev_123', tenant: 'vv', env: 'dev' };
}
function saveCfg(c){ fs.writeFileSync(cfgPath, JSON.stringify(c, null, 2)); }

async function http(baseUrl, apiKey, tenant, env, pathUrl, body, method='POST'){
  const headers = { 'content-type': 'application/json', 'authorization': `ApiKey ${apiKey}`, 'x-tenant': tenant, 'x-env': env };
  const res = await fetch(baseUrl + pathUrl, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let txt = await res.text();
  try { return JSON.parse(txt); } catch { return { raw: txt, status: res.status }; }
}

function printHelp(){
  console.log(`LogLine CLI (skeleton)
Usage:
  logline login --apiKey <token> [--baseUrl https://...] [--tenant vv] [--env dev|stg|prd]
  logline whoami

  # TDLN
  logline tdln:assist  --text "..." [--span span.json]
  logline tdln:decide  --text "..." [--prefer-premium]
  logline tdln:compile --file span.json

  # Container
  logline container:deploy --ref app@1.2.3 --proj rw1 --svc web [--provider railway]
  logline wallet:sign   --kid default --file payload.json
  logline wallet:verify --kid default --file payload.json --sig SIG

  # Contratos
  logline contratos:new  --template nda@v3 --party "Empresa A" --party "Empresa B"
  logline contratos:flow --id NDA-2025-0001 --action sign --actor user:123
  logline contratos:get  --id NDA-2025-0001

  # Memory
  logline memory:search --text "contrato NDA" --topk 5

  # Workflows
  logline wf:start --flow order-approval --input input.json
  logline wf:step  --id wf_123 --step review --input step.json
  logline wf:get   --id wf_123

  # Tools
  logline tools:invoke --tool http --data data.json

  # Prompt
  logline prompt:compile --kernel kernel.md
  logline prompt:run     --kernel kernel.md --vars vars.json

  # Core
  logline span:execute  --file span.json
  logline policy:test   --law laws.yaml
`);
}

async function main(){
  const args = process.argv.slice(2);
  const cfg = loadCfg();
  const get = (flag, def=null) => { const i = args.indexOf(flag); return i>=0 ? args[i+1] : def; };
  const has = (flag) => args.includes(flag);

  const cmd = args[0];
  if(!cmd){ printHelp(); return; }

  if(cmd==='login'){
    const apiKey = get('--apiKey'); if(!apiKey){ console.error('missing --apiKey'); process.exit(1); }
    const baseUrl = get('--baseUrl', cfg.baseUrl);
    const tenant = get('--tenant', cfg.tenant||'vv');
    const env = get('--env', cfg.env||'dev');
    saveCfg({ baseUrl, apiKey, tenant, env });
    console.log('Logged in:', { baseUrl, tenant, env });
    return;
  }
  if(cmd==='whoami'){ console.log(loadCfg()); return; }

  // TDLN
  if(cmd==='tdln:assist'){
    const paragraph = get('--text');
    const spanFile = get('--span', null);
    const span = spanFile ? JSON.parse(fs.readFileSync(path.resolve(spanFile),'utf8')) : undefined;
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.tenant, cfg.env, '/v1/tdln/assist', { paragraph, span });
    console.log(JSON.stringify(res, null, 2)); return;
  }
  if(cmd==='tdln:decide'){
    const paragraph = get('--text');
    const prefer_premium = has('--prefer-premium');
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.tenant, cfg.env, '/v1/tdln/decide', { paragraph, prefer_premium });
    console.log(JSON.stringify(res, null, 2)); return;
  }
  if(cmd==='tdln:compile'){
    const file = get('--file'); if(!file){ console.error('missing --file'); process.exit(1); }
    const span = JSON.parse(fs.readFileSync(path.resolve(file),'utf8'));
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.tenant, cfg.env, '/v1/tdln/compile', { span });
    console.log(JSON.stringify(res, null, 2)); return;
  }

  // Container
  if(cmd==='container:deploy'){
    const ref = get('--ref'); const proj = get('--proj'); const svc = get('--svc'); const provider = get('--provider','railway');
    const body = { ref, target: { provider, project_id: proj, service: svc } };
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.tenant, cfg.env, '/v1/container/deploy', body);
    console.log(JSON.stringify(res, null, 2)); return;
  }
  if(cmd==='wallet:sign'){
    const kid = get('--kid','default'); const file = get('--file');
    const payload = JSON.parse(fs.readFileSync(path.resolve(file),'utf8'));
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.enant, cfg.env, '/v1/container/wallet/sign', { kid, payload });
    console.log(JSON.stringify(res, null, 2)); return;
  }
  if(cmd==='wallet:verify'){
    const kid = get('--kid','default'); const file = get('--file'); const sig = get('--sig');
    const payload = JSON.parse(fs.readFileSync(path.resolve(file),'utf8'));
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.tenant, cfg.env, '/v1/container/wallet/verify', { kid, payload, sig });
    console.log(JSON.stringify(res, null, 2)); return;
  }

  // Contratos
  if(cmd==='contratos:new'){
    const template = get('--template');
    const parts=[]; for(let i=0;i<args.length;i++) if(args[i]=='--party' && args[i+1]) parts.push({ name: args[i+1] });
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.tenant, cfg.env, '/v1/contratos/register', { template, parties: parts });
    console.log(JSON.stringify(res, null, 2)); return;
  }
  if(cmd==='contratos:flow'){
    const id = get('--id'); const action = get('--action'); const actor = get('--actor');
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.tenant, cfg.env, '/v1/contratos/flow', { id, action, actor });
    console.log(JSON.stringify(res, null, 2)); return;
  }
  if(cmd==='contratos:get'){
    const id = get('--id');
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.tenant, cfg.env, `/v1/contratos/${id}`, null, 'GET');
    console.log(JSON.stringify(res, null, 2)); return;
  }

  // Memory
  if(cmd==='memory:search'){
    const text = get('--text'); const topk = parseInt(get('--topk','5'),10);
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.tenant, cfg.env, '/v1/memory/search', { text, topk });
    console.log(JSON.stringify(res, null, 2)); return;
  }

  // Workflows
  if(cmd==='wf:start'){
    const flow = get('--flow'); const inputFile = get('--input');
    const input = inputFile ? JSON.parse(fs.readFileSync(path.resolve(inputFile),'utf8')) : {};
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.tenant, cfg.env, '/v1/workflows/start', { flow, input });
    console.log(JSON.stringify(res, null, 2)); return;
  }
  if(cmd==='wf:step'){
    const id = get('--id'); const step = get('--step'); const inputFile = get('--input');
    const input = inputFile ? JSON.parse(fs.readFileSync(path.resolve(inputFile),'utf8')) : {};
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.tenant, cfg.env, '/v1/workflows/step', { id, step, input });
    console.log(JSON.stringify(res, null, 2)); return;
  }
  if(cmd==='wf:get'){
    const id = get('--id');
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.tenant, cfg.env, `/v1/workflows/${id}`, null, 'GET');
    console.log(JSON.stringify(res, null, 2)); return;
  }

  // Tools
  if(cmd==='tools:invoke'){
    const tool = get('--tool'); const dataFile = get('--data');
    const argsObj = dataFile ? JSON.parse(fs.readFileSync(path.resolve(dataFile),'utf8')) : {};
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.tenant, cfg.env, '/v1/tools/invoke', { tool, args: argsObj });
    console.log(JSON.stringify(res, null, 2)); return;
  }

  // Prompt
  if(cmd==='prompt:compile'){
    const kernelFile = get('--kernel');
    const kernel = fs.readFileSync(path.resolve(kernelFile),'utf8');
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.tenant, cfg.env, '/v1/prompt/compile', { kernel });
    console.log(JSON.stringify(res, null, 2)); return;
  }
  if(cmd==='prompt:run'){
    const kernelFile = get('--kernel'); const varsFile = get('--vars');
    const kernel = fs.readFileSync(path.resolve(kernelFile),'utf8');
    const vars = varsFile ? JSON.parse(fs.readFileSync(path.resolve(varsFile),'utf8')) : {};
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.tenant, cfg.env, '/v1/prompt/run', { kernel, vars });
    console.log(JSON.stringify(res, null, 2)); return;
  }

  // Core
  if(cmd==='span:execute'){
    const file = get('--file'); const span = JSON.parse(fs.readFileSync(path.resolve(file),'utf8'));
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.tenant, cfg.env, '/v1/spans/execute', { span });
    console.log(JSON.stringify(res, null, 2)); return;
  }
  if(cmd==='policy:test'){
    const law = get('--law'); const content = fs.readFileSync(path.resolve(law),'utf8');
    const res = await http(cfg.baseUrl, cfg.apiKey, cfg.tenant, cfg.env, '/v1/policies/evaluate', { law: content });
    console.log(JSON.stringify(res, null, 2)); return;
  }

  printHelp();
}
main().catch(e=>{ console.error(e); process.exit(1); });
