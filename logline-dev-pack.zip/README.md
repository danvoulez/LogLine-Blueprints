# LogLine Dev Pack
Atualizado em 2025-11-17

## Conteúdo
- **openapi/logline-mini-suite.openapi.yaml** — contrato unificado (Universal + mini produtos)
- **sdk/typescript** — SDK TS (ESM) com clientes por produto
- **cli/logline.mjs** — CLI skeleton (Node 18+, usa fetch nativo)

## Quickstart
```bash
# SDK
cd sdk/typescript
npm i -D typescript
npm run build  # gera dist/

# CLI
node cli/logline.mjs login --apiKey <token> --baseUrl https://api.logline.world --tenant vv --env dev
node cli/logline.mjs tdln:assist --text "criar cliente Joana…"
node cli/logline.mjs container:deploy --ref app@1.2.3 --proj rw1 --svc web --provider railway
```
