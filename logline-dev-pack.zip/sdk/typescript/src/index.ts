import { Http } from './http';
export type Env = 'dev'|'stg'|'prd';

export class LogLineClient {
  http: Http;
  core: CoreClient;
  prompt: PromptClient;
  memory: MemoryClient;
  workflows: WorkflowsClient;
  tools: ToolsClient;
  container: ContainerClient;
  contratos: ContratosClient;
  tdln: TDLNClient;

  constructor(cfg: { baseUrl: string, apiKey?: string, tenant?: string, env?: Env }) {
    this.http = new Http(cfg.baseUrl, cfg.apiKey, cfg.tenant, (cfg.env||'dev'));
    this.core = new CoreClient(this.http);
    this.prompt = new PromptClient(this.http);
    this.memory = new MemoryClient(this.http);
    this.workflows = new WorkflowsClient(this.http);
    this.tools = new ToolsClient(this.http);
    this.container = new ContainerClient(this.http);
    this.contratos = new ContratosClient(this.http);
    this.tdln = new TDLNClient(this.http);
  }
}

// Core
export class CoreClient {
  constructor(private http: Http) {}
  executeSpan(span: any){ return this.http.request('/v1/spans/execute', { body: { span } }); }
  evaluatePolicies(input: any){ return this.http.request('/v1/policies/evaluate', { body: input }); }
}

// Prompt
export class PromptClient {
  constructor(private http: Http) {}
  compile(kernel: string, vars?: any){ return this.http.request('/v1/prompt/compile', { body: { kernel, vars } }); }
  run(kernel: string, vars?: any){ return this.http.request('/v1/prompt/run', { body: { kernel, vars } }); }
}

// Memory
export class MemoryClient {
  constructor(private http: Http) {}
  put(item: { key: string, data: any, tags?: string[] }){ return this.http.request('/v1/memory/put', { body: item }); }
  get(key: string){ return this.http.request('/v1/memory/get', { body: { key } }); }
  search(text: string, topk=5){ return this.http.request('/v1/memory/search', { body: { text, topk } }); }
  grant(principal: string, key: string, perm: 'read'|'write'){ return this.http.request('/v1/memory/grant', { body: { principal, key, perm } }); }
}

// Workflows
export class WorkflowsClient {
  constructor(private http: Http) {}
  start(flow: string, input: any){ return this.http.request('/v1/workflows/start', { body: { flow, input } }); }
  step(id: string, step: string, input: any){ return this.http.request('/v1/workflows/step', { body: { id, step, input } }); }
  get(id: string){ return this.http.request(`/v1/workflows/${id}`, { method: 'GET' }); }
}

// Tools
export class ToolsClient {
  constructor(private http: Http) {}
  invoke(tool: string, args: any){ return this.http.request('/v1/tools/invoke', { body: { tool, args } }); }
}

// Container (deploy • wallet • vault)
export class ContainerClient {
  constructor(private http: Http) {}
  deployApply(resource: string, ref: string, target: any, env?: Record<string,string>){
    return this.http.request('/v1/container/deploy', { body: { resource, ref, target, env } });
  }
  walletSign(kid: string, payload: any){ return this.http.request('/v1/container/wallet/sign', { body: { kid, payload } }); }
  walletVerify(kid: string, payload: any, sig: string){ return this.http.request('/v1/container/wallet/verify', { body: { kid, payload, sig } }); }
  vaultPut(name: string, data: any){ return this.http.request('/v1/container/vault/put', { body: { name, data } }); }
  vaultGet(name: string){ return this.http.request('/v1/container/vault/get', { body: { name } }); }
}

// Contratos
export class ContratosClient {
  constructor(private http: Http) {}
  register(template: string, parties: any[], meta?: any){
    return this.http.request('/v1/contratos/register', { body: { template, parties, meta } });
  }
  flow(id: string, action: string, actor: string, payload?: any){
    return this.http.request('/v1/contratos/flow', { body: { id, action, actor, payload } });
  }
  get(id: string){ return this.http.request(`/v1/contratos/${id}`, { method: 'GET' }); }
}

// TDLN
export class TDLNClient {
  constructor(private http: Http) {}
  decide(args: { paragraph?: string, span?: any, ctx?: any, prefer_premium?: boolean }){
    return this.http.request('/v1/tdln/decide', { body: args });
  }
  assist(args: { paragraph?: string, span?: any, ctx?: any }){
    return this.http.request('/v1/tdln/assist', { body: args });
  }
  compile(span: any){
    return this.http.request('/v1/tdln/compile', { body: { span } });
  }
}
