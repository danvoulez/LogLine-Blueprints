export type RequestOptions = {
  method?: string;
  headers?: Record<string,string>;
  body?: any;
};

export class Http {
  constructor(public baseUrl: string, public apiKey?: string, public tenant?: string, public env: 'dev'|'stg'|'prd'='dev') {}
  private buildHeaders(extra: Record<string,string> = {}) {
    const h: Record<string,string> = { 'content-type': 'application/json' };
    if (this.apiKey) h['authorization'] = `ApiKey ${this.apiKey}`;
    if (this.tenant) h['x-tenant'] = this.tenant;
    if (this.env) h['x-env'] = this.env;
    return { ...h, ...extra };
  }
  async request(path: string, opts: RequestOptions = {}) {
    const url = `${this.baseUrl}${path}`;
    const res = await fetch(url, {
      method: opts.method || 'POST',
      headers: this.buildHeaders(opts.headers),
      body: opts.body ? JSON.stringify(opts.body) : undefined
    } as any);
    const txt = await res.text();
    try { return JSON.parse(txt); } catch { return { raw: txt, status: res.status }; }
  }
}
