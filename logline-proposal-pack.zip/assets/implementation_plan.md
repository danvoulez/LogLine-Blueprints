# Plano de Implementação — LogLine Universal
**Duração alvo:** 4 semanas

## Semana 1 — Descoberta & Modelagem
- Mapeamento das 10–20 ações prioritárias (Action Table)
- Definição de Schemas (JSON Schema) e políticas
- Planejamento de adapters para cada ação

## Semana 2 — Gateway & Adapters (v1)
- Implementação do Gateway Universal com `POST /v1/commands` e amigos
- Adapters `envelope → API legada`
- Instrumentação de métricas e recibos
- Início da CLI (comandos básicos) e SDK (send/query/stream)

## Semana 3 — CLI/SDK & Tempo Real
- CLI (comandos humanos + `--watch` SSE)
- SDK TS + bindings (OpenAPI 3.1)
- Webhooks (assinados), DLQ (produção)
- Testes de integração ponta-a-ponta

## Semana 4 — TDLN (opcional) & Onboarding
- TDLN Gate (NL→envelope) para 2–3 ações críticas
- Cookbooks e exemplos (cURL, CLI, SDK, NL)
- Hand-off + treinamento + checklist de go-live
