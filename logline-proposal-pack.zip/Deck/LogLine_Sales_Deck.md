---
marp: true
theme: default
class: lead
paginate: true
backgroundColor: #0b0f14
color: #ffffff
---

# **LogLine Universal**  
API mínima · CLI maximalista · SDK oficial

— Uma camada inteligente por cima da sua API, sem reescrita —

---

## O problema
- APIs crescem e ficam **inconsistentes**
- Clientes e times sofrem com **DX ruim**
- **Erros tolos** (payloads faltando) geram retrabalho
- Falta **tempo real** (SSE/Webhooks) e **idempotência**

---

## A solução LogLine
- **Gateway Universal** (API curta e estável)
- **CLI humana/LLM-first** (complexidade fica no cliente)
- **SDK oficial** (assinatura, idempotência, stream)
- TDLN opcional: **NL → envelope determinístico**

---

## Contrato mínimo (envelope)
```json
{
  "action": "customer.create",
  "resource": "urn:customer/joana",
  "body": { "name": "Joana", "email": "joana@ex.com", "country": "PT" }
}
```
**ACK:** `ok | need_more | invalid` + recibo/idempotência

---

## Transportes universais
- **ACK** imediato
- **SSE** por padrão (tempo real)
- **Webhooks** assinados (replay/DLQ no prod)
- **Polling** como fallback universal

---

## CLI (DX que converte)
- `login`, `whoami`, `status --watch`
- `customers:create`, `orders:refund`, `deploy:up`
- `ai --text "criar cliente Joana..."`  → **TDLN dry-run**

---

## SDK (TS fonte; Py/Go gerados)
- `client.send()` · `client.query()` · `client.stream()`
- Helpers de domínio (`users.create`, `deploy.apply`...)
- Assinatura + idempotência **embutidas**

---

## Segurança
- `Idempotency-Key`, `Nonce`, `Timestamp`
- Assinatura **HMAC/Ed25519**
- Policies/Quotas por ação/tenant
- Recibos com `request_id` + checksum/assinatura

---

## Roadmap de implantação
1. **Descoberta** (10–20 ações)
2. **Gateway + Schemas + Adapters**
3. **CLI/SDK** (brand do cliente)
4. **TDLN** (opcional) + testes e onboarding

---

## Tiers & SLA (visão rápida)
- **Starter:** 1 env, 1 tenant, 50 ações/min, 3 ações, SLA best effort
- **Pro:** 2 env, 3 tenants, 300 ações/min, 10 ações, SLA 99,5%
- **Enterprise:** multi env/tenants, 1000+ ações/min, ilimitado, SLA 99,9%

---

## Resultado
- DX consistente (humano, bot e LLM falam a mesma língua)
- Menos falhas → mais conversões
- Onboarding de novas ações em **horas**, não semanas

---

# Vamos ligar o piloto?
5–10 ações críticas, 4 semanas, time conjunto.
