# Proposta LogLine — Universal API + CLI + SDK
**Data:** 2025-11-17  
**Contato:** LogLine — Sales & Partnerships

## 1. Visão Geral
A LogLine entrega uma camada **Universal** para simplificar e “inteligentizar” qualquer API corporativa, sem reescrita do backend:
- **API mínima (porteira)** com validação determinística (TDLN opcional).
- **CLI maximalista** (DX humana/LLM-first) concentrando a complexidade.
- **SDK oficial** (TS fonte; Python/Go gerados) com assinatura, idempotência e streaming.
- **Transporte universal:** ACK imediato + **SSE/Webhook** + polling.
- **Observabilidade e governança**: recibos, quotas, rate limits, políticas por ação.

## 2. Componentes do Produto
1. **Gateway Universal**
   - `POST /v1/commands` (envelope `action/resource/body`), `POST /v1/commands/query`, `GET /v1/stream`, `POST /v1/webhooks`.
   - Gate determinístico: preenche defaults, normaliza, orienta erros (`ok | need_more | invalid`).
2. **CLI do Cliente**
   - Comandos humanos: `acme users:create`, `acme orders:refund`, `acme deploy:up`…
   - Assinatura, idempotência, retries, `--watch` (SSE), `--no-stream` (polling), `--webhook`.
3. **SDK Oficial**
   - `client.send(envelope)`, `client.query(...)`, `client.stream(...)` + helpers de domínio.
4. **(Opcional) TDLN Gate**
   - Entrada em linguagem natural → envelope determinístico (com LLM para UX de mensagens).

## 3. Escopo da Entrega (v1)
- **Descoberta e mapeamento** das 10–20 ações prioritárias.
- **Schema e políticas** (JSON Schemas; quotas; rate limits).
- **Adapters** `envelope → API legada` (path, query, headers, body).
- **CLI** brand do cliente, com comandos mapeados + flags padrão.
- **SDK** em TypeScript (TS), bindings Python/Go via OpenAPI.
- **SSE + Webhooks** prontos; polling como fallback universal.
- **Cookbook** com exemplos (cURL, NL→envelope, CLI/SDK).

## 4. Roadmap & Prazos
- **Semana 1:** Descoberta & Action Table; schemas mínimos.
- **Semanas 2–3:** Gateway + Adapters + CLI (v1) + SDK (v1).
- **Semana 4:** TDLN opcional, testes e ajustes; entrega assistida e material de onboarding.

## 5. Entregáveis
- Repositório **Gateway Universal** (containerizado), **CLI** e **SDK** (TS).
- **OpenAPI 3.1** dos endpoints universais.
- **Manual de Operação** (deploy, chaves, ambientes) + **Cookbook** de exemplos.
- **Métricas**: taxa `ok/need_more/invalid`, latência Gate, eventos por ação.

## 6. Precificação sugerida (tiers)
Ver `assets/pricing_tiers.csv` para detalhes.
- **Starter:** 1 ambiente, 1 tenant, até 50 ações/min, 3 ações mapeadas, SLA Best Effort.
- **Pro:** 2 ambientes, 3 tenants, até 300 ações/min, 10 ações mapeadas, SLA 99,5% + suporte padrão.
- **Enterprise:** múltiplos ambientes/tenants, 1000+ ações/min, ações ilimitadas, SLA 99,9% + suporte dedicado.

> **White label** completo (marca do cliente, pacotes renomeados) incluso a partir do **Pro** como add-on; incluso no **Enterprise**.

## 7. Segurança
- **Idempotência** (`Idempotency-Key`), **Nonce/Timestamp**, assinatura (HMAC ou Ed25519).
- **Políticas por ação**, quotas por ambiente/tenant.
- **Recibos** com `request_id` e checksum/assinatura. **Auditoria** pronta.

## 8. Sucesso & KPIs
- Tempo de integração de uma nova “ação” < **1 dia**.
- Redução de **30–60%** nas chamadas inválidas (via `need_more` orientado).
- **DX** unificada: uso consistente em humanos, bots, LLMs e serviços.

## 9. Próximos Passos
1. Selecionar o **piloto** (top 5–10 ações).
2. Assinar **SOW** (escopo v1) e iniciar descoberta.
3. Provisionar ambientes/chaves; kickoff técnico.

---
**Anexos:** deck (`Deck/LogLine_Sales_Deck.md`), preços (`assets/pricing_tiers.csv`), plano de implementação (`assets/implementation_plan.md`).