import fetch from 'node-fetch';
import EventSource from 'eventsource';

export class AcmeSDK {
  constructor(cfg){
    this.baseUrl = cfg.baseUrl || 'http://127.0.0.1:8787';
    this.apiKey = cfg.apiKey || 'dev_123';
  }
  headers(extra={}){
    return Object.assign({
      'content-type':'application/json',
      'authorization': `ApiKey ${this.apiKey}`
    }, extra);
  }
  async send(envelope){
    const r = await fetch(`${this.baseUrl}/v1/commands`, { method:'POST', headers:this.headers(), body: JSON.stringify(envelope) });
    return await r.json();
  }
  async query({resource, actionPrefix, sinceId, limit}){
    const r = await fetch(`${this.baseUrl}/v1/commands/query`, { method:'POST', headers:this.headers(), body: JSON.stringify({resource, actionPrefix, sinceId, limit}) });
    return await r.json();
  }
  stream({resource, actionPrefix}, onEvent){
    const qs = new URLSearchParams();
    if(resource) qs.set('resource', resource);
    if(actionPrefix) qs.set('actionPrefix', actionPrefix);
    const es = new EventSource(`${this.baseUrl}/v1/stream?${qs.toString()}`, { headers: this.headers() });
    es.onmessage = (e)=>{ try{ onEvent(JSON.parse(e.data)); }catch{} };
    es.onerror = ()=>{};
    return ()=> es.close();
  }
  // Helpers
  customers = {
    create: async ({resource, name, email, country}) => this.send({ action:'customer.create', resource, body:{ name, email, country } })
  }
  orders = {
    refund: async ({resource, order_id, reason}) => this.send({ action:'order.refund', resource, body:{ order_id, reason } })
  }
  deploy = {
    apply: async ({resource, ref, target}) => this.send({ action:'deploy.apply', resource, body:{ ref, target } })
  }
}
