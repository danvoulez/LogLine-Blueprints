#!/usr/bin/env node
import fs from 'fs';
import path from 'path';
import url from 'url';
import fetch from 'node-fetch';
import EventSource from 'eventsource';

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));
const cfgPath = path.join(__dirname, '.acme-cli.json');

function loadCfg(){
  if(fs.existsSync(cfgPath)) return JSON.parse(fs.readFileSync(cfgPath,'utf8'));
  return { baseUrl: 'http://127.0.0.1:8787', apiKey: 'dev_123' };
}
function saveCfg(c){ fs.writeFileSync(cfgPath, JSON.stringify(c, null, 2)); }
function headers(cfg){ return { 'content-type':'application/json', 'authorization': `ApiKey ${cfg.apiKey}` }; }

async function send(cfg, envelope){
  const r = await fetch(`${cfg.baseUrl}/v1/commands`, { method:'POST', headers: headers(cfg), body: JSON.stringify(envelope) });
  const j = await r.json(); console.log(JSON.stringify(j,null,2)); return j;
}
async function status(cfg, {resource, actionPrefix, watch}){
  if(watch){
    const qs = new URLSearchParams(); if(resource) qs.set('resource',resource); if(actionPrefix) qs.set('actionPrefix',actionPrefix);
    const es = new EventSource(`${cfg.baseUrl}/v1/stream?${qs.toString()}`, { headers: headers(cfg) });
    es.onmessage = e => console.log('EVENT', e.data);
    es.onerror = ()=>{};
    console.log('Watching... (Ctrl+C to exit)');
  } else {
    const r = await fetch(`${cfg.baseUrl}/v1/commands/query`, { method:'POST', headers: headers(cfg), body: JSON.stringify({ resource, actionPrefix, limit:100 }) });
    const j = await r.json(); console.log(JSON.stringify(j,null,2));
  }
}

async function main(){
  const args = process.argv.slice(2);
  const cfg = loadCfg();

  const cmd = args[0];
  if(cmd === 'login'){
    const idx = args.indexOf('--apiKey');
    const apiKey = idx>=0 ? args[idx+1] : process.env.ACME_API_KEY;
    if(!apiKey){ console.error('Usage: acme login --apiKey <token>'); process.exit(1); }
    cfg.apiKey = apiKey; saveCfg(cfg); console.log('Logged in.'); return;
  }
  if(cmd === 'whoami'){
    console.log(JSON.stringify(cfg,null,2)); return;
  }
  if(cmd === 'ai'){
    const idx = args.indexOf('--text');
    const text = idx>=0 ? args[idx+1] : args[1];
    if(!text){ console.error('Usage: acme ai --text "<paragraph>"'); process.exit(1); }
    const r = await fetch(`${cfg.baseUrl}/v1/universal`, { method:'POST', headers: headers(cfg), body: JSON.stringify({ paragraph: text, dry_run: true }) });
    console.log(JSON.stringify(await r.json(), null, 2)); return;
  }
  if(cmd === 'send'){
    const file = args[1];
    if(!file){ console.error('Usage: acme send <envelope.json>'); process.exit(1); }
    const env = JSON.parse(fs.readFileSync(path.resolve(file),'utf8'));
    await send(cfg, env); return;
  }
  if(cmd === 'status'){
    const resIdx = args.indexOf('--resource');
    const resource = resIdx>=0 ? args[resIdx+1] : null;
    const watch = args.includes('--watch');
    await status(cfg, { resource, actionPrefix: null, watch });
    return;
  }
  if(cmd === 'customers:create'){
    const name = args[args.indexOf('--name')+1];
    const email = args[args.indexOf('--email')+1];
    const country = args[args.indexOf('--country')+1];
    const resource = args[args.indexOf('--resource')+1];
    await send(cfg, { action:'customer.create', resource, body:{ name, email, country } });
    return;
  }
  if(cmd === 'orders:refund'){
    const oidx = args.indexOf('--order');
    const ridx = args.indexOf('--reason');
    const order_id = oidx>=0 ? args[oidx+1] : undefined;
    const reason = ridx>=0 ? args[ridx+1] : undefined;
    const resIdx = args.indexOf('--resource');
    const resource = resIdx>=0 ? args[resIdx+1] : (order_id ? `urn:order/${order_id}` : undefined);
    await send(cfg, { action:'order.refund', resource, body:{ order_id, reason } });
    return;
  }
  if(cmd === 'deploy:up'){
    const ref = args[args.indexOf('--ref')+1];
    const proj = args[args.indexOf('--proj')+1];
    const svc = args[args.indexOf('--svc')+1];
    const target = { provider: 'railway', project_id: proj, service: svc };
    const resIdx = args.indexOf('--resource');
    const resource = resIdx>=0 ? args[resIdx+1] : 'urn:app/web';
    await send(cfg, { action:'deploy.apply', resource, body:{ ref, target } });
    return;
  }
  console.log(`ACME CLI Demo
Usage:
  acme login --apiKey <token>
  acme whoami
  acme ai --text "<paragraph>"
  acme send envelope.json
  acme status --resource <urn> [--watch]
  acme customers:create --name "Joana" --email joana@ex.com --country PT --resource urn:customer/joana
  acme orders:refund --order 123 --reason "customer request" [--resource urn:order/123]
  acme deploy:up --ref app@1.0 --proj rw1 --svc web [--resource urn:app/web]`);
}

main().catch(e=>{ console.error(e); process.exit(1); });
