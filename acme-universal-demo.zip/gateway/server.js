import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import { createServer } from 'http';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs';
import path from 'path';
import url from 'url';
import fetch from 'node-fetch';

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));
const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: '2mb' }));

const PORT = process.env.PORT || 8787;
const API_KEYS = (process.env.API_KEYS || 'dev_123').split(',').map(s=>s.trim());

const mapping = JSON.parse(fs.readFileSync(path.join(__dirname,'mapping.json'),'utf8'));

// In-memory stores for demo
const events = [];   // {id, ts, action, resource, body, status}
const sseClients = new Set(); // response objects
const webhooks = []; // {id,url,events}
let nextEventId = 1;

function nowISO(){ return new Date().toISOString(); }

function ackOk(envelope, requestId){
  return {
    status: 'ok',
    trace_id: requestId,
    receipt: {
      ts: nowISO(),
      hash: 'checksum-demo-' + requestId,
      signature: 'demo-signature'
    }
  };
}

function ackNeedMore(requestId, missing, why, suggested){
  return { status:'need_more', trace_id: requestId, missing_fields: missing, why, suggested_reply: suggested || 'Please provide required fields.' };
}

function ackInvalid(requestId, errors, suggested){
  return { status:'invalid', trace_id: requestId, errors, suggested_reply: suggested || 'Please review the request.' };
}

function requireApiKey(req, res){
  const auth = req.headers['authorization'] || '';
  const token = auth.startsWith('ApiKey ') ? auth.slice(7) : null;
  if(!token || !API_KEYS.includes(token)){
    res.status(401).json({ error: 'Unauthorized' });
    return false;
  }
  return true;
}

function pushEvent(evt){
  const id = String(nextEventId++);
  const full = { id, ...evt };
  events.push(full);
  // SSE broadcast
  const data = `id: ${id}\ndata: ${JSON.stringify(full)}\n\n`;
  for(const res of sseClients){
    try { res.write(data); } catch {}
  }
  // Webhook stubs
  for(const wh of webhooks){
    if(!wh.events || wh.events.length===0 || wh.events.includes(evt.action) || wh.events.includes('*')){
      fetch(wh.url, { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify(full)}).catch(()=>{});
    }
  }
}

function validateEnvelope(envelope){
  const errors = [];
  if(!envelope || typeof envelope !== 'object'){
    errors.push('invalid envelope');
    return { ok:false, errors };
  }
  const { action, resource, body } = envelope;
  if(!action) errors.push('action is required');
  if(!resource) errors.push('resource is required');
  if(errors.length) return { ok:false, errors };
  const spec = mapping[action];
  if(!spec) return { ok:false, errors:[`unknown action: ${action}`] };
  const required = spec.required || [];
  const missing = [];
  for(const r of required){
    if(body==null || !(r in body)) missing.push(r);
  }
  if(missing.length) return { ok:false, missing };
  return { ok:true };
}

// POST /v1/commands
app.post('/v1/commands', (req, res)=>{
  if(!requireApiKey(req, res)) return;
  const requestId = uuidv4();
  const envelope = req.body;
  const v = validateEnvelope(envelope);
  if(v.ok){
    pushEvent({ ts: nowISO(), action: envelope.action, resource: envelope.resource, body: envelope.body, status: 'accepted' });
    res.json(ackOk(envelope, requestId));
  } else if(v.missing){
    const why = Object.fromEntries(v.missing.map(m=>[m, 'required field']));
    res.status(200).json(ackNeedMore(requestId, v.missing, why, 'Missing required fields.'));
  } else {
    res.status(200).json(ackInvalid(requestId, v.errors, 'Unknown action or malformed envelope.'));
  }
});

// POST /v1/commands/query
app.post('/v1/commands/query', (req, res)=>{
  if(!requireApiKey(req, res)) return;
  const { resource, actionPrefix, sinceId, limit=100 } = req.body || {};
  let result = events.slice();
  if(resource) result = result.filter(e=>e.resource===resource);
  if(actionPrefix) result = result.filter(e=>e.action.startsWith(actionPrefix));
  let startIdx = 0;
  if(sinceId){
    const idx = events.findIndex(e=>e.id === String(sinceId));
    if(idx>=0) startIdx = idx+1;
  }
  result = result.slice(startIdx, startIdx+limit);
  const cursor = result.length ? result[result.length-1].id : sinceId || null;
  res.json({ items: result, cursor });
});

// GET /v1/stream
app.get('/v1/stream', (req, res)=>{
  if(!requireApiKey(req, res)) return;
  const { resource, actionPrefix } = req.query;
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no'
  });
  const client = res;
  sseClients.add(client);

  const ping = setInterval(()=>{ try{ client.write(': ping\n\n'); }catch{} }, 15000);

  const filtered = events.filter(e => (!resource || e.resource===resource) && (!actionPrefix || e.action.startsWith(actionPrefix)));
  for(const e of filtered.slice(-5)){
    client.write(`id: ${e.id}\ndata: ${JSON.stringify(e)}\n\n`);
  }

  req.on('close', ()=>{ clearInterval(ping); sseClients.delete(client); });
});

// POST /v1/webhooks
app.post('/v1/webhooks', (req, res)=>{
  if(!requireApiKey(req, res)) return;
  const { url, events: evs } = req.body || {};
  if(!url) return res.status(400).json({ error: 'url is required' });
  const id = uuidv4();
  webhooks.push({ id, url, events: evs || ['*'] });
  res.json({ id });
});

// POST /v1/universal (very naive demo)
app.post('/v1/universal', (req, res)=>{
  if(!requireApiKey(req, res)) return;
  const { paragraph, dry_run=true } = req.body || {};
  if(!paragraph || typeof paragraph!=='string'){
    return res.status(400).json({ error: 'paragraph is required' });
  }
  const lower = paragraph.toLowerCase();
  let envelope = null;
  if(lower.includes('cadastrar') || lower.includes('create customer')){
    envelope = { action:'customer.create', resource:'urn:customer/joana', body:{ name:'Joana', email:'joana@ex.com', country:'PT' } };
  } else if(lower.includes('refund')){
    envelope = { action:'order.refund', resource:'urn:order/123', body:{ order_id:'123', reason:'customer request' } };
  } else if(lower.includes('deploy')){
    envelope = { action:'deploy.apply', resource:'urn:app/web', body:{ ref:'app@1.0', target:{ provider:'railway', project_id:'rw1', service:'web' } } };
  }
  if(!envelope){
    return res.json({ status:'invalid', trace_id: uuidv4(), errors:['could not infer action'], suggested_reply:'Describe the operation clearly (e.g., "create customer with name/email/country")' });
  }
  const v = validateEnvelope(envelope);
  if(!v.ok){
    return res.json(ackNeedMore(uuidv4(), v.missing||[], {}, 'Please provide missing fields.'));
  }
  if(dry_run){
    return res.json({ status:'ok', trace_id: uuidv4(), compiled: envelope });
  } else {
    pushEvent({ ts: nowISO(), action: envelope.action, resource: envelope.resource, body: envelope.body, status: 'accepted' });
    return res.json(ackOk(envelope, uuidv4()));
  }
});

createServer(app).listen(PORT, ()=>{
  console.log(`[ACME Gateway] listening on http://127.0.0.1:${PORT}`);
});
