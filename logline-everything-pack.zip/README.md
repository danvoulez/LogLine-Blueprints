# LogLine — Everything Pack
Atualizado em 2025-11-17

## Conteúdos
- **packages/** — pacotes prontos para uso
  - `acme-universal-demo.zip` — API+CLI+SDK demo (white-label)
  - `logline-proposal-pack-v2.zip` — Proposta + Deck + Governança
  - `logline-blueprints-ready.zip` — Blueprints normalizados + Deck
- **docs/** — documentação adicional
  - `Blueprint_TDLN_LLM_Council_Pack.md` — TDLN + Conselho de LLM (Mini & Max)

## Quick start
1. Abra `logline-proposal-pack-v2.zip` → `Proposal/` e `Deck/` (Marp).
2. Abra `logline-blueprints-ready.zip` → `INDEX.md` e `LogLine_Blueprints_Deck.md`.
3. (Opcional) Rode o **ACME demo**: `gateway` + `sdk` + `cli` dentro de `acme-universal-demo.zip`.
4. Estude o `docs/Blueprint_TDLN_LLM_Council_Pack.md` para integrar o **TDLN Gate**.

## Observações
- Alguns artefatos são demos (sem spans/TDLN reais) para acelerar *pitch/piloto*.
- A versão “LogLine Premium” inclui TDLN Max, spans e governança completa.
